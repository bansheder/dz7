<?php
ini_set('display_errors', 'On');
error_reporting(E_ALL);
include 'db.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $message = trim($_POST['message']);
    if (strlen($username) < 10 || strlen($message) < 10 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo 'Пожалуйста, заполните все поля корректно.';
    } else {
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $browser = $_SERVER['HTTP_USER_AGENT'];
        
        $stmt = $pdo->prepare("INSERT INTO messages (username, email, message, ip_address, browser) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$username, $email, $message, $ip_address, $browser]);
        echo 'Сообщение добавлено!';
    }
}

$messages_per_page = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $messages_per_page;
$stmt = $pdo->prepare("SELECT * FROM messages ORDER BY created_at DESC LIMIT $messages_per_page OFFSET $offset");
$stmt->execute();
$messages = $stmt->fetchAll();
$stmt = $pdo->query("SELECT COUNT(*) FROM messages");
$total_messages = $stmt->fetchColumn();
$total_pages = ceil($total_messages / $messages_per_page);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Гостевая книга</title>
</head>
<body>

<h1>Гостевая книга</h1>
<form method="POST">
    <label for="username">Имя пользователя (минимум 10 символов):</label>
    <input type="text" id="username" name="username" required minlength="10"><br>

    <label for="email">Адрес электронной почты:</label>
    <input type="email" id="email" name="email" required><br>

    <label for="message">Сообщение (минимум 10 символов):</label>
    <textarea id="message" name="message" required minlength="10"></textarea><br>

    <button type="submit">Отправить сообщение</button>
</form>

<hr>

<?php foreach ($messages as $message): ?>
    <div>
        <strong><?= htmlspecialchars($message['username']) ?></strong> (<?= htmlspecialchars($message['email']) ?>) - 
        <em><?= htmlspecialchars($message['browser']) ?></em> <br>
        <small><?= $message['created_at'] ?> - IP: <?= htmlspecialchars($message['ip_address']) ?></small>
        <p><?= nl2br(htmlspecialchars($message['message'])) ?></p>
    </div>
    <hr>
<?php endforeach; ?>

<div>
    <?php if ($page > 1): ?>
        <a href="?page=<?= $page - 1 ?>">Предыдущая</a>
    <?php endif; ?>
    
    <span>Страница <?= $page ?> из <?= $total_pages ?></span>

    <?php if ($page < $total_pages): ?>
        <a href="?page=<?= $page + 1 ?>">Следующая</a>
    <?php endif; ?>
</div>

</body>
</html>
